
export const ADD_CITY="ADD_CITY";



export const addCity=(city)=>({
    type:ADD_CITY,
    payload:city
})