
export const ADD_TOKEN="ADD_TOKEN";



export const addToken=(token)=>({
    type:ADD_TOKEN,
    payload:token
})